#include "mbed.h"
#include "motor.h"
#include "pid.h"
#include "util.h"

#define SAMPLE_TIME     0.05
#define SENDRATE        0.05

//Structures
struct MotorData {
    uint16_t setpoint;
    uint16_t actual;
    PID pid;
    Motor *esc;
};

T_CharCurvePoint rpm_vs_freq[] = {
    {  0,      0}, 
    {100,      0}, {147,   1230}, {269,   2220}, 
    {365,   3000}, {440,   3600}, {510,   4170}, 
    {555,   4620}, {600,   5010}, {640,   5340}, 
    {670,   5670}, {700,   5970}, {725,   6300}, 
    {770,   6660}, {800,   6990}, {860,   7350},
    {900,   7800}, {930,   8130}, {9999,  8130}
};

//Globals
MotorData motor1;
MotorData motor2;
MotorData motor3;
MotorData motor4;

long rpm1_counts = 0;
long rpm2_counts = 0;
long rpm3_counts = 0;
long rpm4_counts = 0;

int ssonar = -1;
int operational = 0;
int RESOLUTION = (int)(((5000.0*SAMPLE_TIME) + 1.0)/SAMPLE_TIME - 5000.0);

DigitalOut hb_light(LED1);
AnalogIn sonar(p19);
Serial pc(USBTX, USBRX);
Serial ser(p9,p10);
InterruptIn rpm1(p15);
InterruptIn rpm2(p16);
InterruptIn rpm3(p17);
InterruptIn rpm4(p18);
Motor esc1(p26);
Motor esc2(p25);
Motor esc3(p24);
Motor esc4(p23);

Ticker hb_ticker;
Ticker control_ticker;
Ticker debug_ticker;

//Prototypes
int setup();
void hb();
void rpm1_counter();
void rpm2_counter();
void rpm3_counter();
void rpm4_counter();
void debug();
void control_helper(long &rpm, MotorData &motor);
void control_loop();
void update_sonar();


int main() {
    char c;
    char buf[256];
    int m1,m2,m3,m4;
    int i=0;
    
    setup();

    while(1) {
        c = ser.getc();
        switch(c) {
            case '\n':
                buf[i] = '\0';
                sscanf(buf,"%d,%d,%d,%d",&m1,&m2,&m3,&m4);
                motor1.setpoint = LIMIT(0,m1,8000);
                motor2.setpoint = LIMIT(0,m2,8000);
                motor3.setpoint = LIMIT(0,m3,8000);
                motor4.setpoint = LIMIT(0,m4,8000);
                i = 0;
                memset(buf,0,256);
                break;
            case 'S':
                ser.printf("1\n");
                break;
            case 'D':
                ser.printf("%d,%d,%d,%d,%d\n",
                    motor1.setpoint,
                    motor2.setpoint,
                    motor3.setpoint,
                    motor4.setpoint,
                    ssonar
                );
                break;
            default:
                buf[i++] = c;
                break;
        }
    }
}


int setup() {

    //Communication Interfaces Setup
    pc.baud(115200);
    ser.baud(115200);
    pc.printf("Initializing...");
    
    //Interrupts Setup    
    rpm1.rise(&rpm1_counter);
    rpm2.rise(&rpm2_counter);
    rpm3.rise(&rpm3_counter);
    rpm4.rise(&rpm4_counter);
    
    //Control Loops Setup
    int ok = motor1.pid.init(50,40,0,5,100);
    ok |= motor2.pid.init(50,40,0,5,100);
    ok |= motor3.pid.init(50,40,0,5,100);
    ok |= motor4.pid.init(50,40,0,5,100);
    
    motor1.esc = &esc1;
    motor2.esc = &esc2;
    motor3.esc = &esc3;
    motor4.esc = &esc4;
    
    esc1.idle();
    esc2.idle();
    esc3.idle();
    esc4.idle();
    
    if(ok != 0) {
        pc.printf("FAILED\r\n");
        return -1;
    } else {
        pc.printf("SUCCESS\r\n");
    }

    hb_ticker.attach(hb,1.0);
    control_ticker.attach(control_loop,SAMPLE_TIME);
    debug_ticker.attach(debug,0.5);
    
    return 0;
}

void hb() {
    hb_light = !hb_light;
}

void rpm1_counter() {
    ++rpm1_counts;
}

void rpm2_counter() {
    ++rpm2_counts;
}

void rpm3_counter() {
    ++rpm3_counts;
}

void rpm4_counter() {
    ++rpm4_counts;
}
double in = -1;
void debug() {
    pc.printf("M1:%6d(%6d)    M2:%6d(%6d)    M3:%6d(%6d)    M4:%6d(%6d)\r\n",
        motor1.actual,motor1.setpoint,
        motor2.actual,motor2.setpoint,
        motor3.actual,motor3.setpoint,
        motor4.actual,motor4.setpoint
    );
    //pc.printf("%f,%d\r\n",in,ssonar);
}

void control_helper(long &rpm, MotorData &motor) {
    uint16_t out;
    uint16_t freq = (uint16_t)((double)rpm/SAMPLE_TIME);
    rpm = 0;
    
    motor.actual = char_curve(rpm_vs_freq,freq);
    
    int s = (motor.actual > motor.setpoint) ? -1.0 : 1.0;
    if(s > 0) {
         motor.pid.regulate(motor.setpoint,motor.actual,out);
    } else {
         motor.pid.regulate(motor.actual,motor.setpoint,out);
    }
    
    if(!inDeadBand((uint64_t)motor.actual,(uint64_t)motor.setpoint,RESOLUTION)) {
        motor.esc->write(motor.esc->read() + ((double)s*(double)out)/10000);
    }
}

void control_loop() {
    control_helper(rpm1_counts,motor1);
    control_helper(rpm3_counts,motor3);
    control_helper(rpm2_counts,motor2);
    control_helper(rpm4_counts,motor4);
    update_sonar();
}

//6.4 mV/in
void update_sonar() {
    // xV = %norm x 3.3V
    //
    //  xV     1000 mV     1 in
    // ----- x -------- x -------- = in
    //   1        1 V      6.4 mV
    //
    // in = %norm x 3.3 x 1000 / 6.4
    // in = %norm x 515.625
    // Adding 0.5 is for rounding up :)
    in = sonar.read()*515.625 + 0.5;
    ssonar = (int)in;
}