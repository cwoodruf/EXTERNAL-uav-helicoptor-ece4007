#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x81a2bdc0, "module_layout" },
	{ 0xf9a482f9, "msleep" },
	{ 0x2e5810c6, "__aeabi_unwind_cpp_pr1" },
	{ 0x194f2d04, "pwm_off" },
	{ 0x57069cb6, "pwm_devs" },
	{ 0x1d027e4b, "snd_pcm_format_signed" },
	{ 0xe707d823, "__aeabi_uidiv" },
	{ 0x27e1a049, "printk" },
	{ 0x55e39de0, "snd_pcm_set_ops" },
	{ 0x66518dab, "snd_pcm_lib_free_pages" },
	{ 0x22c54b3a, "snd_pcm_lib_ioctl" },
	{ 0x96695896, "set_pwm_frequency" },
	{ 0xdec5f319, "snd_pcm_lib_malloc_pages" },
	{ 0x68a24153, "snd_pcm_format_physical_width" },
	{ 0x46c033d6, "set_duty_cycle" },
	{ 0x221de525, "snd_pcm_lib_preallocate_pages_for_all" },
	{ 0xefd6cf06, "__aeabi_unwind_cpp_pr0" },
	{ 0xbcf06d9c, "snd_pcm_new" },
	{ 0xe914e41e, "strcpy" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=pwm";

