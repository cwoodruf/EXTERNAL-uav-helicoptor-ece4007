#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x81a2bdc0, "module_layout" },
	{ 0x3ec8886f, "param_ops_int" },
	{ 0x72aa82c6, "param_ops_charp" },
	{ 0xb78c61e8, "param_ops_bool" },
	{ 0xa20fb014, "platform_driver_unregister" },
	{ 0xb7c940cc, "platform_driver_register" },
	{ 0x27e1a049, "printk" },
	{ 0x748ffa75, "snd_card_register" },
	{ 0x3c2c5af5, "sprintf" },
	{ 0xe914e41e, "strcpy" },
	{ 0x7c9fe7d9, "snd_pwmsp_new_pcm" },
	{ 0x3f42473d, "snd_device_new" },
	{ 0xf96002e6, "snd_card_create" },
	{ 0xabfde321, "dev_set_drvdata" },
	{ 0x8cfeb571, "snd_card_free" },
	{ 0x2e5810c6, "__aeabi_unwind_cpp_pr1" },
	{ 0xefd6cf06, "__aeabi_unwind_cpp_pr0" },
	{ 0x4491ad68, "snd_pcm_suspend_all" },
	{ 0xa65d3911, "pwmsp_sync_stop" },
	{ 0x968c451f, "dev_get_drvdata" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=pwmsp_lib";

