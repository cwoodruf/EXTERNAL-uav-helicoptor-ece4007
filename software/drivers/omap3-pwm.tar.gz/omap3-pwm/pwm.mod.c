#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x81a2bdc0, "module_layout" },
	{ 0x9998c01f, "cdev_del" },
	{ 0xba270f6b, "cdev_init" },
	{ 0xfbc74f64, "__copy_from_user" },
	{ 0x3ec8886f, "param_ops_int" },
	{ 0x67c2fa54, "__copy_to_user" },
	{ 0x97255bdf, "strlen" },
	{ 0x222227eb, "malloc_sizes" },
	{ 0x20000329, "simple_strtoul" },
	{ 0xb0bb9c02, "down_interruptible" },
	{ 0xbe12e1e4, "device_destroy" },
	{ 0x7485e15e, "unregister_chrdev_region" },
	{ 0xe707d823, "__aeabi_uidiv" },
	{ 0xfa2a45e, "__memzero" },
	{ 0x5f754e5a, "memset" },
	{ 0x27e1a049, "printk" },
	{ 0x8ac1c000, "device_create" },
	{ 0x61651be, "strcat" },
	{ 0x1b7d45c7, "cdev_add" },
	{ 0x26c5d0eb, "kmem_cache_alloc" },
	{ 0xe9ce8b95, "omap_ioremap" },
	{ 0x15331242, "omap_iounmap" },
	{ 0x37a0cba, "kfree" },
	{ 0x9d669763, "memcpy" },
	{ 0x8cf51d15, "up" },
	{ 0x47defc3c, "class_destroy" },
	{ 0xefd6cf06, "__aeabi_unwind_cpp_pr0" },
	{ 0x701d0ebd, "snprintf" },
	{ 0x2dd65650, "__class_create" },
	{ 0x29537c9e, "alloc_chrdev_region" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";

